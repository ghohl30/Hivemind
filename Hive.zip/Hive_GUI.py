import tkinter as tk
from math import cos, sin, sqrt, radians
import hive

class App(tk.Tk):

    def __init__(self): 
        super().__init__()
        self.title("Hive")
        self.geometry("900x1000")
        self.width = 700
        self.height = 700
        self.canvas = tk.Canvas(self,background="green" ,width=self.width, height=self.height)
        # add padiing to canvas
        self.canvas.pack(padx=10, pady=10)

        # initialize coordinates
        self.x, self.y = self.width/2, self.height/2
        self.q, self.s, self.r = 0, 0, 0

        # set size of the hexagon
        self.size = 30
        self.angle = 60

        # draw initially highlighted hexagon
        self.draw_hexagon(0,0,0,tag='hover', outline='red', width=3, fill='red')

        # set up mouse click event
        self.canvas.bind('<Motion>', self.motion)

        # set up hive
        self.setup_hive()

        # set up for movement
        self.setup_move()   

        # render the board
        self.rerender_board()    

    def setup_hive(self):
        self.player1 = hive.HumanPlayer("Gregor")
        self.player2 = hive.HumanPlayer("Viviana")
        self.game = hive.Game(self.player1, self.player2)
        self.current_player = self.player1

    def setup_move(self):
        self.clicknum = 0
        self.place_piece = False
        self.move_from = None
        self.move_to = None
        self.canvas.bind('<Button-1>', self.click)
        color = self.get_color()
        # self.button = tk.Button(self, text="Place {} piece".format(color), command=self.placement_mode)
        # self.button.pack()
        self.place_buttons = []

    def get_color(self):
        return "white" if self.current_player == self.player1 else "black"

    def placement_mode(self, piece_type):
        self.place_piece = True
        self.piece = self.game.board.get_piece(None, self.current_player, piece_type)
        self.clicknum = 1

    def hex_to_pixel(self, q, s, r):
        x = (3/2)*self.size*q + self.width/2
        y = self.size*sqrt(3)*q/2 + self.size*sqrt(3)*r + self.height/2
        return x, y

    def pixel_to_hex(self, x, y):
        q = (x - self.width/2)*(2/3)/self.size
        r = -(1/3)*(x - self.width/2)/self.size + (y - self.height/2) * (sqrt(3)/3)/self.size
        s = q + r
        return q, s, r

    def hexagon_corners(self, xc, yc):
        coords = []
        for i in range(6):
            x = xc + self.size * cos(radians(self.angle * i))
            y = yc + self.size * sin(radians(self.angle * i))
            coords.append([x,y])
        return coords

    def draw_hexagon(self, q, s, r, tag='hexagon', outline='gray', width=2, fill='white', piece = None, mounting=False):
        x,y = self.hex_to_pixel(q,s,r)
        textfill = "green" if not mounting else "red"
        txt = str(piece)
        self.canvas.create_polygon(self.hexagon_corners(x,y), outline=outline, fill=fill, width=width, tags=tag)
        if piece is None:
            self.canvas.create_text(x, y, text=str(q)+","+str(s)+","+str(r), fill="green", tags=tag)
        else:
            self.canvas.create_text(x, y, text=txt, fill=textfill, tags=tag)

    def motion(self, event):
        self.x, self.y = event.x, event.y

        # get q,r,s from pixel coordinates
        q, s, r = self.pixel_to_hex(self.x, self.y)
        # round q,r,s to correct hexagon
        q, s, r = self.cube_round(q, s, r)

        # if coordinates don´t match currently highlighted hexagon, change it
        if self.q != q or self.r != r or self.s != s:
            self.canvas.delete('hover')
            self.draw_hexagon(q, s, r, tag='hover', outline='red', width=3, fill='red')
            self.q, self.s, self.r = q, s, r

    def click(self, event):
        if self.clicknum == 0:
            if self.place_piece == True:
                self.move_from = None
                self.clicknum += 1
                self.place_piece = False
            else:
                self.piece = self.game.board.get_piece([self.q, self.s, self.r])
                if self.piece is not None and self.piece.player == self.current_player:
                    self.move_from = [self.q, self.s, self.r]
                    self.clicknum += 1
        elif self.clicknum == 1:
            self.move_to = [self.q, self.s, self.r]
            self.clicknum = 0
            # edge_to_move = self.game.board.get_edge(self.move_to)
            move = hive.Move(self.current_player, self.piece, self.move_to)
            print(self.piece)
            if self.game.make_move(move):
                q, s, r = self.move_to
                self.change_turn()
            else: 
                print("invalid move")

    def change_turn(self):
        self.current_player = self.game.turn
        self.clicknum = 0
        self.place_piece = False
        color = self.get_color()
        # self.button.config(text="Place {} piece".format(color))
        # rerender board
        self.rerender_board()

    def rerender_board(self):
        self.canvas.delete('all')
        pieces = self.game.board.pieces
        for piece in pieces:
            if piece.position is not None:
                q, s, r = piece.position
                color = "white" if piece.player == self.player1 else "black"
                self.draw_hexagon(q, s, r, tag="{},{},{}".format(q,s,r), outline='gray', width=2, fill=color, piece=piece.__str__(), mounting=hasattr(piece, 'mounting') and piece.mounting)

        # delete the "place piece" buttons
        for button in self.place_buttons:
            button.destroy()
        
        piece_types = set([piece.__str__() for piece in self.game.board.pieces if piece.position is None and piece.mounted == False and piece.player == self.current_player])
        for piece_type in piece_types:
            button = tk.Button(self, text=piece_type, command=lambda type=piece_type: self.placement_mode(type))
            button.pack()
            self.place_buttons.append(button)
        


    @staticmethod
    def cube_round(q,s,r):
        q_round, r_round, s_round = int(round(q)), int(round(r)), int(round(s))

        q_diff = abs(q_round - q)
        r_diff = abs(r_round - r)
        s_diff = abs(s_round - s)

        if q_diff > r_diff and q_diff > s_diff:
            q_round = -r_round + s_round
        elif r_diff > s_diff:
            r_round = -q_round + s_round
        else:
            s_round = q_round + r_round

        return q_round, s_round, r_round


if __name__ == '__main__':
    app = App()
    app.mainloop()


    